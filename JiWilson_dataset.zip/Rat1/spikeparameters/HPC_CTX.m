
clear;clc;close all
 
rat_opt = 2


str = ['/Users/zhechen/Documents/MATLAB/hmm_topology/Ji_data/Data_4_25_2014/Rat' num2str(rat_opt) '/run.sess']
S = load(str,'-mat');
pinfo = S.pinfo; S = [];
T0 = pinfo.posdata.postimestamp(1) * 0.0001;  % in second
T1 = pinfo.posdata.postimestamp(end) * 0.0001;

if rat_opt == 1
    % 52/57 sorted units  ([1-31,54] from CA1; [32,33,34] from V2; [35:53] from V1)
    CTX = [32:53]; CTX = [32:52];
    No_CTX = length(CTX);
    HPC = [1:31,54]; HPC = [1,2,4,6:22,25:31]; % many low firing 
    HPC = [1 2 4 6 10 13 14 16 18 19 20 21 22 27 30 31]; 
    No_HPC = length(HPC);
    %    No_Visual = 21;   
    %    No_HPC =    16/27;
    
elseif rat_opt == 2
    % 66/70 sorted units  ([2:18,28:65,67] from CA1; [1,19:27,66] from V1)
    CTX = [1,19:27];
    No_CTX = length(CTX);
    HPC = [2:18,28:65,67];
    HPC = [2:4, 7:13, 16, 18, 30:33,35,37,39,43,46,49,50,55,56,57,59 65];
    No_HPC = length(HPC);
    %    No_Visual = 10;   
    %    No_HPC =    28/56;
    
elseif rat_opt == 3
    % 38/41 sorted units  ([13:38] from CA1; [1:12] from V1), but some empty 
    CTX = [1:12]; CTX = [1:7,9:12];
    No_CTX = length(CTX);
    HPC = [13:38]; HPC = [13:29, 31:37];
    No_HPC = length(HPC);
    %    No_Visual = 11;   
    %    No_HPC =    24;
    
end

binsize = 0.25;
edges = [T0: binsize:T1];
HPC_spikecount = zeros(No_HPC, length(edges));
CTX_spikecount = zeros(No_CTX, length(edges));

for c=1:No_HPC
   spiketimes = pinfo.data{HPC(c)};
   tem = histc(spiketimes,edges);
   HPC_spikecount(c,:) = tem; 
end
for c=1:No_CTX
   spiketimes = pinfo.data{CTX(c)};
   tem = histc(spiketimes,edges);
   CTX_spikecount(c,:) = tem; 
end


% run period 

% interpolate the animal's position in cm
% 0.67 cm/ pixel
xx = interp1(pinfo.posdata.postimestamp*0.0001, pinfo.posdata.xpos*0.67, edges,'spline');  % cm
yy = interp1(pinfo.posdata.postimestamp*0.0001, pinfo.posdata.ypos*0.67, edges,'spline');  % cm
vel = sqrt(diff(xx).^2 + diff(yy).^2)/binsize;         
run_ind = find(vel>15);
length(run_ind)



%%
figure;subplot(121);
imagesc(cov([HPC_spikecount; CTX_spikecount]'));axis square
hold on;plot([No_HPC No_HPC],[1 No_HPC+No_CTX],'b--','linewidth',1)
hold on;plot([1 No_HPC+No_CTX],[No_HPC No_HPC],'b--','linewidth',1)
axis xy;colormap(flipud(bone));
ylabel('Cell','fontsize',16);
xlabel('Cell','fontsize',16);
title('ALL period','fontsize',20);
set(gca,'fontsize',18);


subplot(122);
imagesc(cov([HPC_spikecount(:,run_ind); CTX_spikecount(:,run_ind)]'));axis square
hold on;plot([No_HPC No_HPC],[1 No_HPC+No_CTX],'b--','linewidth',1)
hold on;plot([1 No_HPC+No_CTX],[No_HPC No_HPC],'b--','linewidth',1)
axis xy;colormap(flipud(bone));
ylabel('Cell','fontsize',16);
xlabel('Cell','fontsize',16);
title('RUN period','fontsize',20);
set(gca,'fontsize',18);


figure;
imagesc([HPC_spikecount(:,run_ind); CTX_spikecount(:,run_ind)]);
axis xy;colormap(flipud(bone));
ylabel('Cell','fontsize',16);
xlabel('Time bin','fontsize',16);
set(gca,'fontsize',18);


% generalized eigenvalue decomposition (CCA) 

% two covariance matrices 

[V,D] = eig(cov(HPC_spikecount(:,run_ind)), cov(CTX_spikecount(:,run_ind)));


